-- phpMyAdmin SQL Dump
-- version 4.6.6
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Czas generowania: 03 Cze 2017, 12:23
-- Wersja serwera: 10.0.31-MariaDB
-- Wersja PHP: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Baza danych: `seorogal_stach`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `config`
--

DROP TABLE IF EXISTS `config`;
CREATE TABLE IF NOT EXISTS `config` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'id tabeli',
  `name` varchar(16) NOT NULL COMMENT 'nazwa parametru',
  `value` varchar(255) NOT NULL COMMENT 'wartosc parametru',
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='tabela konfiguracyjna';

--
-- Zrzut danych tabeli `config`
--

INSERT INTO `config` (`id`, `name`, `value`) VALUES
(1, 'login', 'zakladstacha'),
(2, 'pass', '79489d0ddf6b7b0ea0c32b7111c065a2');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `gallery`
--

DROP TABLE IF EXISTS `gallery`;
CREATE TABLE IF NOT EXISTS `gallery` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'id tabeli',
  `title` varchar(40) DEFAULT NULL COMMENT 'tytuł zdjęcia',
  `description` varchar(255) DEFAULT NULL COMMENT 'opis zdjęcia',
  `src` varchar(255) NOT NULL COMMENT 'ścieżka url do zdjęcia',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=136 DEFAULT CHARSET=utf8 COMMENT='Tabela przechowująca dane zdjec galeri';

--
-- Zrzut danych tabeli `gallery`
--

INSERT INTO `gallery` (`id`, `title`, `description`, `src`) VALUES
(1, '', '', '/img/gallery/1.JPG'),
(2, NULL, NULL, './img/gallery/2.JPG'),
(3, NULL, NULL, './img/gallery/3.JPG'),
(4, NULL, NULL, './img/gallery/4.JPG'),
(7, NULL, NULL, './img/gallery/5.JPG'),
(8, NULL, NULL, './img/gallery/6.JPG'),
(9, NULL, NULL, './img/gallery/7.JPG'),
(10, NULL, NULL, './img/gallery/8.JPG'),
(11, NULL, NULL, './img/gallery/9.JPG'),
(12, '', '', '/img/gallery/tn_1.jpg'),
(13, '', '', '/img/gallery/11.jpg'),
(15, '', '', '/img/gallery/tn_13.jpg'),
(16, '', '', '/img/gallery/tn_14.jpg'),
(17, '', '', '/img/gallery/tn_dsc_0673.jpg'),
(18, '', '', '/img/gallery/tn_dsc_0674.jpg'),
(19, '', '', '/img/gallery/tn_dsc_0679.jpg'),
(20, '', '', '/img/gallery/tn_dsc_0689.jpg'),
(21, '', '', '/img/gallery/tn_dsc_0060.jpg'),
(22, '', '', '/img/gallery/tn_dsc_0072.jpg'),
(24, '', '', '/img/gallery/tn_dsc_0074.jpg'),
(25, '', '', '/img/gallery/tn_dsc_0078.jpg'),
(26, '', '', '/img/gallery/tn_dsc_0109.jpg'),
(27, '', '', '/img/gallery/tn_dsc_0111.jpg'),
(28, '', '', '/img/gallery/tn_dsc_0112.jpg'),
(29, '', '', '/img/gallery/tn_dsc_0114.jpg'),
(30, '', '', '/img/gallery/tn_dsc_0118.jpg'),
(31, '', '', '/img/gallery/tn_dsc_0125.jpg'),
(32, '', '', '/img/gallery/tn_dsc_0131.jpg'),
(33, '', '', '/img/gallery/tn_dsc_0138.jpg'),
(34, '', '', '/img/gallery/tn_dsc_0249.jpg'),
(36, '', '', '/img/gallery/tn_dsc_0181.jpg'),
(37, '', '', '/img/gallery/tn_dsc_0412.jpg'),
(38, '', '', '/img/gallery/tn_dsc_0419.jpg'),
(39, '', '', '/img/gallery/tn_dsc_0423.jpg'),
(40, '', '', '/img/gallery/tn_dsc_0432.jpg'),
(41, '', '', '/img/gallery/tn_dsc_0436.jpg'),
(42, '', '', '/img/gallery/tn_dsc_0440.jpg'),
(43, '', '', '/img/gallery/tn_dsc_0443.jpg'),
(44, '', '', '/img/gallery/tn_dsc_0455.jpg'),
(45, '', '', '/img/gallery/tn_dsc_0459.jpg'),
(46, '', '', '/img/gallery/tn_dsc_0463.jpg'),
(47, '', '', '/img/gallery/tn_dsc00084.jpg'),
(48, '', '', '/img/gallery/tn_dsc00086.jpg'),
(49, '', '', '/img/gallery/tn_dsc00087.jpg'),
(50, '', '', '/img/gallery/tn_dsc00090.jpg'),
(51, '', '', '/img/gallery/tn_dsc00093.jpg'),
(52, '', '', '/img/gallery/tn_dsc00096.jpg'),
(53, '', '', '/img/gallery/tn_dsc00100.jpg'),
(54, '', '', '/img/gallery/tn_dsc00105.jpg'),
(55, '', '', '/img/gallery/tn_dsc00107.jpg'),
(56, '', '', '/img/gallery/tn_dsc_0662.jpg'),
(57, '', '', '/img/gallery/tn_dsc_0668.jpg'),
(58, '', '', '/img/gallery/tn_dsc_0670.jpg'),
(59, '', '', '/img/gallery/tn_dsc_0687.jpg'),
(60, '', '', '/img/gallery/tn_dsc_0695.jpg'),
(61, '', '', '/img/gallery/tn_dsc_0682.jpg'),
(62, '', '', '/img/gallery/tn_dsc_0496.jpg'),
(64, '', '', '/img/gallery/tn_dsc_0588.jpg'),
(65, '', '', '/img/gallery/tn_dsc_0591.jpg'),
(66, '', '', '/img/gallery/tn_dsc_0598.jpg'),
(67, '', '', '/img/gallery/tn_dsc_0628.jpg'),
(68, '', '', '/img/gallery/tn_dsc_0701.jpg'),
(69, '', '', '/img/gallery/tn_dsc_0685.jpg'),
(71, '', '', '/img/gallery/tn_dsc_0997.jpg'),
(72, '', '', '/img/gallery/tn_dsc_0998.jpg'),
(73, '', '', '/img/gallery/tn_dsc_0999.jpg'),
(74, '', '', '/img/gallery/tn_dsc_0433.jpg'),
(75, '', '', '/img/gallery/tn_dsc_0454.jpg'),
(76, '', '', '/img/gallery/tn_dsc_0547.jpg'),
(77, '', '', '/img/gallery/tn_dsc_0609.jpg'),
(78, '', '', '/img/gallery/tn_dsc_0573.jpg'),
(79, '', '', '/img/gallery/tn_dsc_0580.jpg'),
(80, '', '', '/img/gallery/tn_dsc_0601.jpg'),
(81, '', '', '/img/gallery/tn_sushi25.jpg'),
(82, '', '', '/img/gallery/tn_img_9108.jpg'),
(83, '', '', '/img/gallery/tn_img_9143.jpg'),
(85, '', '', '/img/gallery/tn_sushi27.jpg'),
(86, '', '', '/img/gallery/tn_dsc_0921.jpg'),
(87, '', '', '/img/gallery/tn_dsc_0930.jpg'),
(88, '', '', '/img/gallery/tn_dsc00090.jpg'),
(89, '', '', '/img/gallery/tn_dsc_0939.jpg'),
(90, '', '', '/img/gallery/tn_dsc_0947.jpg'),
(91, '', '', '/img/gallery/tn_dsc_0736.jpg'),
(92, '', '', '/img/gallery/tn_dsc_0727.jpg'),
(93, '', '', '/img/gallery/tn_dsc_0741.jpg'),
(94, '', '', '/img/gallery/tn_dsc_0759.jpg'),
(95, '', '', '/img/gallery/tn_dsc_0755.jpg'),
(96, '', '', '/img/gallery/tn_dsc_0719.jpg'),
(97, '', '', '/img/gallery/tn_img_0525.jpg'),
(98, '', '', '/img/gallery/tn_img_0518.jpg'),
(99, '', '', '/img/gallery/tn_img_0517.jpg'),
(100, '', '', '/img/gallery/tn_img_0514.jpg'),
(101, '', '', '/img/gallery/tn_img_0526.jpg'),
(102, '', '', '/img/gallery/tn_dsc_0355.jpg'),
(103, '', '', '/img/gallery/tn_dsc_0354.jpg'),
(104, '', '', '/img/gallery/tn_dsc_0346.jpg'),
(105, '', '', '/img/gallery/tn_dsc_0363.jpg'),
(106, '', '', '/img/gallery/tn_20140411_121017.jpg'),
(107, '', '', '/img/gallery/tn_20130708_134104.jpg'),
(108, '', '', '/img/gallery/tn_dsc_0119.jpg'),
(109, '', '', '/img/gallery/tn_img_0565.jpg'),
(110, '', '', '/img/gallery/tn_img_0563.jpg'),
(111, '', '', '/img/gallery/tn_img_0568.jpg'),
(112, '', '', '/img/gallery/tn_img_0571.jpg'),
(113, '', '', '/img/gallery/tn_img_0869.jpg'),
(114, '', '', '/img/gallery/tn_img_0888.jpg'),
(115, '', '', '/img/gallery/tn_img_0886.jpg'),
(116, '', '', '/img/gallery/tn_img_0882.jpg'),
(117, '', '', '/img/gallery/tn_img_1018.jpg'),
(118, '', '', '/img/gallery/tn_img_0989.jpg'),
(119, '', '', '/img/gallery/tn_img_0989.jpg'),
(120, '', '', '/img/gallery/tn_img_0988.jpg'),
(121, '', '', '/img/gallery/tn_img_1417.jpg'),
(122, '', '', '/img/gallery/tn_img_1423.jpg'),
(123, '', '', '/img/gallery/tn_img_1774.jpg'),
(124, '', '', '/img/gallery/tn_img_1780.jpg'),
(125, '', '', '/img/gallery/tn_img_1868.jpg'),
(126, '', '', '/img/gallery/tn_img_1880.jpg'),
(127, '', '', '/img/gallery/tn_img_1882.jpg'),
(128, '', '', '/img/gallery/tn_img_1883.jpg'),
(129, '', '', '/img/gallery/tn_img_1885.jpg'),
(130, '', '', '/img/gallery/tn_img_1971.jpg'),
(135, '', '', '/img/gallery/dsc_0948.jpg');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
